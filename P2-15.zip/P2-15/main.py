import re
from pyspark.sql import SparkSession

def process_tweets():
    # Create a SparkSession
    spark = SparkSession.builder \
        .appName("Top 20 Hashtags Analysis") \
        .getOrCreate()

    # Read the file containing tweets
    tweet_rows = spark.read.text('s3://p2-inputdata/smallTwitter.json').rdd.map(lambda row: row.value)

    # Extract hashtags from all tweets and convert them to lowercase
    all_hashtags = tweet_rows.flatMap(lambda tweet_text: re.findall(r'#(\w+)', tweet_text)).map(lambda hashtag: hashtag.lower())

    # Count the occurrences of each lowercase hashtag
    hashtag_counts = all_hashtags.map(lambda hashtag: (hashtag, 1)).reduceByKey(lambda a, b: a + b)

    # Get the top 20 hashtags
    top_20_hashtags = hashtag_counts.takeOrdered(20, key=lambda x: -x[1])

    # Output the top 20 hashtags
    print("Top 20 Hashtags:")
    for tag, count in top_20_hashtags:
        print(f"{tag}: {count}")

    # Prepare the output string
    output_string = "\n".join([f"{tag}: {count}" for tag, count in top_20_hashtags])

    # Write the output to a file in your S3 bucket
    output_path = "s3://cloudcomputingvt/Visruta/output.txt"
    spark.sparkContext.parallelize([output_string]).saveAsTextFile(output_path)
    
    # Stop the SparkSession
    spark.stop()

if __name__ == "__main__":
    process_tweets()

