package helloworld.book;

import java.util.List;

public interface BookDao {

    public Book findByBookId(long bookId);

    public List<Book> findByCategoryId(long categoryId);

    public List<Book> findByCategoryName(String categoryName);
    public List<Book> findRandomByCategoryId(long categoryId, int limit);
    public List<Book> findRandomBooksByCategoryName(String categoryName, int limit);

    public List<Book> getTopRatedBooks(int limit);

    List<Book> findAll();

    void saveBook(Book book);
}
