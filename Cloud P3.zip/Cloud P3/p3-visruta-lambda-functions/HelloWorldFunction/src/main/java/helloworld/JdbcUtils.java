package helloworld;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JdbcUtils {
    private static final String dbHost = System.getenv("DB_HOST");
    private static final String USER_NAME = System.getenv("DB_USER");
    private static final String PASSWORD = System.getenv("DB_PASSWORD");


    public static Connection getConnection() {
        try {
            System.out.println(dbHost + " " + USER_NAME + " " + PASSWORD);
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://" + dbHost + ":3306/p3visrutadatabase";
            return DriverManager.getConnection(url, USER_NAME, PASSWORD);
        } catch (SQLException e) {
            throw new BookstoreDbException("Encountered a SQL issue getting a connection" + e.getMessage(), e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}