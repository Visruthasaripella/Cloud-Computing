
package helloworld.category;

public record Category(long categoryId, String name) {}
