package helloworld.category;

public class CategoryDTO {

    public long categoryID;
    public String name;

    public CategoryDTO(String name) {
        this.name = name;
    }

    public long getCategoryID() {
        return categoryID;
    }

    public void setCategoryID(long categoryID) {
        this.categoryID = categoryID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
