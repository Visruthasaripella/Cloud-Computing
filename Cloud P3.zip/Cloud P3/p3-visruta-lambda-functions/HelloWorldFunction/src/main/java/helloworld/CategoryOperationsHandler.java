package helloworld;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyResponseEvent;
import com.fasterxml.jackson.databind.ObjectMapper;
import helloworld.category.Category;
import helloworld.category.CategoryDao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CategoryOperationsHandler implements RequestHandler<APIGatewayProxyRequestEvent, APIGatewayProxyResponseEvent> {
    private final CategoryDao categoryDao = ApplicationContext.INSTANCE.getCategoryDao();

    @Override
    public APIGatewayProxyResponseEvent handleRequest(final APIGatewayProxyRequestEvent input, final Context context) {
        String httpMethod = input.getHttpMethod();
        String path = input.getPath();
        Map<String, String> queryParameters = input.getQueryStringParameters();
        String body = input.getBody();
        APIGatewayProxyResponseEvent response = new APIGatewayProxyResponseEvent();
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");

        switch (httpMethod + ":" + path) {
            case "GET:/api/getAllCategories":
                return getAllCategories(response, headers);
            case "GET:/api/getCategoryName":
                return getCategoryName(queryParameters.get("categoryId"), response, headers);
            case "GET:/api/getCategoryId":
                return getCategoryId(queryParameters.get("name"), response, headers);
            case "POST:/api/addCategory":
                return addCategory(body, response, headers);
            default:
                response.setStatusCode(404);
                response.setHeaders(headers);
                response.setBody("Resource not found");
                return response;
        }
    }

    private APIGatewayProxyResponseEvent getAllCategories(APIGatewayProxyResponseEvent response, Map<String, String> headers) {
        List<Category> categoryList = categoryDao.findAll();
        response.setStatusCode(200);
        response.setHeaders(headers);
        response.setBody(categoryList.toString()); // JSON serialization needed
        return response;
    }

    private APIGatewayProxyResponseEvent getCategoryName(String categoryId, APIGatewayProxyResponseEvent response, Map<String, String> headers) {
        Category category = categoryDao.findByCategoryId(Long.parseLong(categoryId));
        response.setStatusCode(200);
        response.setHeaders(headers);
        response.setBody(category!=null? category.name() : "Category not found");
        return response;
    }

    private APIGatewayProxyResponseEvent getCategoryId(String categoryName, APIGatewayProxyResponseEvent response, Map<String, String> headers) {
        Category category = categoryDao.findByName(categoryName);
        response.setStatusCode(200);
        response.setHeaders(headers);
        response.setBody(category!=null? String.valueOf(category.categoryId()) : "Category not found");
        return response;
    }

    private APIGatewayProxyResponseEvent addCategory(String category, APIGatewayProxyResponseEvent response, Map<String, String> headers) {
        try{
            ObjectMapper mapper = new ObjectMapper();
            Category category1 = mapper.readValue(category, Category.class);
            categoryDao.save(category1);
            response.setStatusCode(201); // 201 Created
            response.setHeaders(headers);
            response.setBody(category1.name() +" created successfully"); // JSON serialization needed
        }catch (Exception e){
            response.setStatusCode(400);
            response.setHeaders(headers);
            response.setBody("{\"error\":\"Invalid JSON format\"}");
        }
        return response;
    }
}
