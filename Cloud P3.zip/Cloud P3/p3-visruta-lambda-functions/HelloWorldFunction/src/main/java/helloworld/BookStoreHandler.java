/*
package helloworld;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyResponseEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import helloworld.book.Book;
import helloworld.book.BookDao;
import helloworld.category.Category;
import helloworld.category.CategoryDao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class BookStoreHandler implements RequestHandler<APIGatewayProxyRequestEvent, APIGatewayProxyResponseEvent> {
    private final BookDao bookDao = ApplicationContext.INSTANCE.getBookDao();
    private final CategoryDao categoryDao = ApplicationContext.INSTANCE.getCategoryDao();
    @Override
    public APIGatewayProxyResponseEvent handleRequest(final APIGatewayProxyRequestEvent input, final Context context) {
        String httpMethod = input.getHttpMethod();
        String path = input.getPath();
        Map<String, String> queryParameters = input.getQueryStringParameters();
        String body = input.getBody();
        APIGatewayProxyResponseEvent response = new APIGatewayProxyResponseEvent();
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        switch (httpMethod + ":" + path) {
            case "GET:/api/getAllCategories":
                return getAllCategories(response, headers);
            case "GET:/api/getCategoryName":
                return getCategoryName(queryParameters.get("categoryId"), response, headers);
            case "GET:/api/getCategoryId":
                return getCategoryId(queryParameters.get("name"), response, headers);
            case "POST:/api/addCategory":
                return addCategory(body, response, headers);
            case "GET:/api/getAllBooks":
                return getAllBooks(response, headers);
            case "GET:/api/getBookById":
                return getBookById(queryParameters.get("bookId"), response, headers);
            case "GET:/api/getBooksByCategoryId":
                return getBooksByCategoryId(queryParameters.get("categoryId"), response, headers);
            case "GET:/api/getBooksByCategoryName":
                return getBooksByCategoryName(queryParameters.get("name"), response, headers);
            case "GET:/api/getRandomBook":
                return getRandomBook(response, headers);
            case "POST:/api/addBook":
                return addBook(body, response, headers);
            default:
                response.setStatusCode(404);
                response.setHeaders(headers);
                response.setBody(path);
                return response;
        }
    }

    private APIGatewayProxyResponseEvent addBook(String body, APIGatewayProxyResponseEvent response, Map<String, String> headers) {
        ObjectMapper mapper = new ObjectMapper();
        Book book = null;
        try {
            book = mapper.readValue(body, Book.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        bookDao.saveBook(book);
        response.setStatusCode(201); // 201 Created
        response.setHeaders(headers);
        response.setBody(book.title() +" created successfully"); // JSON serialization needed
        return response;
    }

    private APIGatewayProxyResponseEvent getRandomBook(APIGatewayProxyResponseEvent response, Map<String, String> headers) {
        response.setStatusCode(200);
        response.setHeaders(headers);
        List<Book> books = bookDao.findRandomBooksByCategoryName("Classics",1);
        response.setBody(books.toString()); // Assuming an empty array for demonstration
        return response;
    }

    private APIGatewayProxyResponseEvent getBooksByCategoryName(String name, APIGatewayProxyResponseEvent response, Map<String, String> headers) {
        response.setStatusCode(200);
        response.setHeaders(headers);
        Category category = categoryDao.findByName(name);
        List<Book> books = bookDao.findByCategoryId(category.categoryId());
        response.setBody(books.toString()); // Assuming an empty array for demonstration
        return response;
    }

    private APIGatewayProxyResponseEvent getAllCategories(APIGatewayProxyResponseEvent response, Map<String, String> headers) {
        response.setStatusCode(200);
        response.setHeaders(headers);
        List<Category> categoryList = categoryDao.findAll();
        response.setBody(categoryList.toString()); // Assuming an empty array for demonstration
        return response;
    }
    private APIGatewayProxyResponseEvent getCategoryName(String categoryId, APIGatewayProxyResponseEvent response, Map<String, String> headers) {
        Category category = categoryDao.findByCategoryId(Long.parseLong(categoryId));
        response.setStatusCode(200);
        response.setHeaders(headers);
        response.setBody(category!=null? category.name() : "Category not found");
        return response;
    }
    // Get category ID by name
    private APIGatewayProxyResponseEvent getCategoryId(String categoryName, APIGatewayProxyResponseEvent response, Map<String, String> headers) {
        Category category = categoryDao.findByName(categoryName);
        response.setStatusCode(200);
        response.setHeaders(headers);
        response.setBody(category!=null? String.valueOf(category.categoryId()) : "Category not found"); // Handling null might need adjustment
        return response;
    }

    // Add a new category
    private APIGatewayProxyResponseEvent addCategory(String category, APIGatewayProxyResponseEvent response, Map<String, String> headers) {
        try{
            ObjectMapper mapper = new ObjectMapper();
            Category category1 = mapper.readValue(category, Category.class);
            categoryDao.save(category1);
            response.setStatusCode(201); // 201 Created
            response.setHeaders(headers);
            response.setBody(category1.name() +" created successfully"); // JSON serialization needed

        }catch (Exception e){
            response.setStatusCode(400);
            response.setHeaders(headers);
            response.setBody("{\"error\":\"Invalid JSON format\"}");
        }

        return response;
    }

    // Get all books
    private APIGatewayProxyResponseEvent getAllBooks(APIGatewayProxyResponseEvent response, Map<String, String> headers) {
        List<Book> bookList = bookDao.findAll();
        response.setStatusCode(200);
        response.setHeaders(headers);
        response.setBody(bookList.toString()); // JSON serialization needed
        return response;
    }
    private APIGatewayProxyResponseEvent getBookById(String bookId, APIGatewayProxyResponseEvent response, Map<String, String> headers) {
        Book book = bookDao.findByBookId(Integer.parseInt(bookId));
        response.setStatusCode(book!=null ? 200 : 404);
        response.setHeaders(headers);
        response.setBody(book!=null? String.valueOf(book) :"{\"error\":\"Book not found\"}"); // Proper JSON response
        return response;
    }
    private APIGatewayProxyResponseEvent getBooksByCategoryId(String categoryId, APIGatewayProxyResponseEvent response, Map<String, String> headers) {
        List<Book> books = bookDao.findByCategoryId(Integer.parseInt(categoryId));
        response.setStatusCode(200);
        response.setHeaders(headers);
        response.setBody(books.toString());
        return response;
    }

}
*/
